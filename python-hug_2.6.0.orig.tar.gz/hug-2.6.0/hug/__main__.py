import hug

hug.development_runner.hug.interface.cli()
