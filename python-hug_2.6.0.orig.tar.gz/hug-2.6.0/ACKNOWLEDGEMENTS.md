Core Developers
===================
- Timothy Edmund Crosley (@timothycrosley)
- Brandon Hoffman (@BrandonHoffman)
- Jason Tyler (@jay-tyler)
- Fabian Kochem (@vortec)

Notable Bug Reporters
===================
- Michael Buckner (@michaelbuckner)
- Carl Neuhaus (@carlneuhaus)
- Eirik Rye (@eirikrye)
- Matteo Bertini (@naufraghi)
- Erwin Haasnoot (@ErwinHaasnoot)
- Aris Pikeas (@pikeas)

Code Contributors
===================
- Kostas Dizas (@kostasdizas)
- Ali-Akber Saifee (@alisaifee)
- @arpesenti
- Eirik Rye (@eirikrye)
- Matteo Bertini (@naufraghi)
- Trevor Scheitrum (@trevorscheitrum)
- Ian Wagner (@ianthetechie)
- Erwin Haasnoot (@ErwinHaasnoot)
- Kirk Leon Guerrero (@kirklg)
- Ergo_ (@johnlam)
- Rodrigue Cloutier (@rodcloutier)
- KhanhIceTea (@khanhicetea)
- Prashant Sinha (@PrashntS)
- Alan Lu (@cag)
- Soloman Weng (@soloman1124)
- Evan Owen (@thatGuy0923)
- Gemedet (@gemedet)
- Garrett Squire (@gsquire)
- Haïkel Guémar (@hguemar)
- Eshin Kunishima (@mikoim)
- Mike Adams (@mikeadamz)
- Michal Bultrowicz (@butla)
- Bogdan (@spock)
- @banteg
- Philip Bjorge (@philipbjorge)
- Daniel Metz (@danielmmetz)
- Alessandro Amici (@alexamici)
- Trevor Bekolay (@tbekolay)
- Elijah Wilson (@tizz98)
- Chelsea Dole (@chelseadole)
- Antti Kaihola (@akaihola)
- Christopher Goes (@GhostOfGoes)
- Stanislav (@atmo)
- Lordran (@xzycn)
- Stephan Fitzpatrick (@knowsuchagency)
- Edvard Majakari (@EdvardM)

Documenters
===================
- Timothy Cyrus (@tcyrus)
- M.Yasoob Ullah Khalid (@yasoob)
- Lionel Montrieux (@lmontrieux)
- Ian Wagner (@ianthetechie)
- Andrew Murray (@radarhere)
- Tim (@timlyo)
- Sven-Hendrik Haase (@svenstaro)
- Matt Caldwell (@mattcaldwell)
- berdario (@berdario)
- Cory Taylor (@coryandrewtaylor)
- James C. (@JamesMCo)
- Ally Weir (@allyjweir)
- Steven Loria (@sloria)
- Patrick Abeya (@wombat2k)
- Ergo_ (@johnlam)
- Adeel Khan (@adeel)
- Benjamin Williams (@benjaminjosephw)
- @gdw2
- Thierry Colsenet (@ThierryCols)
- Shawn Q Jackson (@gt50)
- Bernhard E. Reiter (@bernhardreiter)
- Adam McCarthy (@mccajm)
- Sobolev Nikita (@sobolevn)
- Chris (@ckhrysze)
- Amanda Crosley (@waddlelikeaduck)
- Chelsea Dole (@chelseadole)
- Joshua Crowgey (@jcrowgey)
- Antti Kaihola (@akaihola)
- Simon Ince (@Simon-Ince)
- Edvard Majakari (@EdvardM)



--------------------------------------------

A sincere thanks to everyone who has helped make hug the great Python3 project it is today!

~Timothy Crosley
