def hi():
    return "hi"
