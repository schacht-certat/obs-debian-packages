# mongodb + hug microservice

1. Run with `sudo /path/to/docker-compose up --build`
2. Add data with something that can POST, e.g. `curl http://localhost:8000/new -d name="my name" -d description="a description"`
3. Visit `localhost:8000/` to see all the current data
4. Rejoice!

