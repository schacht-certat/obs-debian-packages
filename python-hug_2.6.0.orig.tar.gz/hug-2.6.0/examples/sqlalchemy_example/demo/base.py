from sqlalchemy.ext.declarative.api import declarative_base

Base = declarative_base()
