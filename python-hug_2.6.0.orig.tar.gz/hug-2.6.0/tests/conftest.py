"""Configuration for test environment"""
import sys

from .fixtures import *
