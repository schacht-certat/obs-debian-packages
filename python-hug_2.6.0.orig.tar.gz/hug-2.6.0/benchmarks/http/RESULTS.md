Latest benchmark results:

hug_test:
        Requests per second:    7518.20 [#/sec] (mean)
        Complete requests:      20000
falcon_test:
        Requests per second:    8186.67 [#/sec] (mean)
        Complete requests:      20000
flask_test:
        Requests per second:    5536.62 [#/sec] (mean)
        Complete requests:      20000
bobo_test:
        Requests per second:    6572.28 [#/sec] (mean)
        Complete requests:      20000
cherrypy_test:
        Requests per second:    3404.87 [#/sec] (mean)
        Complete requests:      20000
pyramid_test:
        Requests per second:    5961.53 [#/sec] (mean)
        Complete requests:      20000

