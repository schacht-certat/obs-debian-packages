.. _testing:

Testing
=======

Reference
---------

.. automodule:: falcon.testing
    :members: Result, Cookie,
        simulate_request, simulate_get, simulate_head, simulate_post,
        simulate_put, simulate_options, simulate_patch, simulate_delete,
        TestClient, TestCase, SimpleTestResource, StartResponseMock,
        capture_responder_args, rand_string, create_environ, redirected,
        closed_wsgi_iterable
